Dataset: https://www.kaggle.com/datasets/nikhilroxtomar/brain-tumor-segmentation
